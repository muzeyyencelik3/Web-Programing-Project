using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using MovieApp.Models;



namespace MovieApp.Data
{

    public static class MovieRepository
    {

        private static List<Movie> _movies = new List<Movie>();

        static MovieRepository()
        {
            _movies = new List<Movie>()
          {

              new Movie()
               {
                Id=1,
                Name="Dabbe",
                 ShortDescription="Harror",
                  Description="Henüz 2006 yılına girilmemişken, Amerika Birleşik Devletleri'nde sıra dışı intihar olayları baş göstermektedir. Türkiye'de bunlara benzer ilk vaka İzmir ilinin Selçuk ilçesinde meydana gelir. İnternet ile arası diğer insanlara oranla daha iyi olan Tarık, ortada hiçbir sebep yokken feci bir şekilde canına kıymıştır. Tarık'ın yakın arkadaşları Sema, Hande ve Cem komiser Süleyman tarafından sorgulanır ama bir sonuç alınmaz. İlerleyen günlerde Cem'e Tarık'ın adresinden bir elektronik posta gelir. Bir ölünün yaşayanlarla iletişim kurması mümkün müdür? Peki ya başka boyuttan varlıkların birer virüs gibi internet üzerinden bulaşıyor olması? Dabbe'tül Arz ortaya çıkıp, gerçekler hayalle karıştığında imkânsız diye bir şey de kalmayacaktır.",
                   CategoryId=1,
                     ImageUrl="Dabbe.jpg"
                },
              
              new Movie()
               {
               Id=2,
               Name="Recep İvedik",
                ShortDescription="Comedy",
                  Description="Recep İvedik sokakta bulduğu bir cüzdanın Antalyalı çok önemli bir iş adamına ait olduğunu öğrenince güneye doğru yola koyulur. Yol boyunca birbirinden komik sürprizlerle karşılaşan Recep sonunda Antalya'ya varır ve cüzdanı turizmci Muhsin Bey'e teslim eder. Muhsin Bey ona para ile otelinde kalmasını teklif eder. Recep bunu kabul etmez ve tam giderken, çocukluk aşkı Sibel'i görür ancak Sibel onu tanımaz. Bunun üzerine Recep otelde kalmayı kabul eder. Recep otelde Sibel'e yaranmaya çalışırken birbirinden komik olaylar yaşar.",
                   CategoryId=2,
                    ImageUrl="Recepİvedik.jpg"
               },
              
              new Movie()
              {
              Id=3,
              Name="Şampiyon",
                ShortDescription="Romantic",
                 Description="Bizim İçin Şampiyon, Ahmet Katıksız'ın 2018 yılında yönettiği ve Serkan Yörük ile birlikte senaryosunu yazdığı dramatik ve biyografik Türk Sinema filmidir. Yarış atı Bold Pilot ve jokeyi Halis Karataş'ın gerçek hikâyesi anlatılmaktadır.[1] Filmde Bold Pilot'ı canlandıran at, Bold Bilot'ın oğlu Ganesh'tir.",
                  CategoryId=3,
                   ImageUrl="Şampiyon.jpg"
              },
              
              new Movie()
               {
                Id=4,
                Name="Twilight",
                 ShortDescription="Love-fantasy",
                  Description="On yedi yaşındaki Bella Swan annesi Renée evlenince babası Charlie'nin yanında yaşamak üzere küçük bir kasaba olan Forks, Washington'a taşınır. Burada yüz sekiz yaşında bir vampir olup on yedi yaşında görünen gizemli sınıf arkadaşı Edward Cullen ile tanışır ve ona hemen ilk gördüğü anda ilgi duymaya başlar. Edward ilk başlarda Bella'dan uzak durmaya çalışmasına rağmen, sonrasında birbirlerine geri dönülemez bir şekilde âşık olurlar. Üç göçebe vampir James, Victoria ve Laurent geldiğinde ise, Bella'nın hayatı tehlikeye girer ve Edward'ın ailesi Carlisle, Esme, Alice, Jasper, Emmett ve Rosalie onun hayatını çok geç olmadan kurtarmak için uğraşırlar.",
                   CategoryId=4,
                    ImageUrl="twilight.jpg"
              }


          };
        }
        public static List<Movie> Movies
        {
            get
            {
                return _movies;
            }
        }

        public static void AddMovie(Movie entity)
        {
            _movies.Add(entity);
        }


        public static Movie GetById(int id)
        {

            return _movies.FirstOrDefault(i => i.Id == id);
        }



    }

}